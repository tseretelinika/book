from ext import db
from sqlalchemy import ForeignKey

class BaseModel:
    def create(self):
        db.session.add(self)
        db.session.commit()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    @staticmethod
    def save():
        db.session.commit()

class Book(db.Model, BaseModel):
    __tablename__ = "books"
    id = db.Column(db.Integer(), primary_key=True)
    title = db.Column(db.String(), nullable=False)
    author = db.Column(db.String(), nullable=False)

    image = db.Column(db.String(), default="book1.jpg")

class Review(db.Model, BaseModel):
    __tablename__ = "reviews"

    id = db.Column(db.Integer(), primary_key = True)
    text = db.Column(db.String(), nullable=False)
    movie_id = db.Column(ForeignKey("books.id"))
