from ext import db

class Book(db.Model):
    __tablename__ = "books"
    id = db.Column(db.Integer(), primary_key=True)
    title = db.Column(db.String(), nullable=False)
    author = db.Column(db.String(), nullable=False)
    rating = db.Column(db.Float(), nullable=False)
    image = db.Column(db.String(), default="book1.jpg")
    description = db.Column(db.String(), default="")
