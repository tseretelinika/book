from ext import app, db
from flask import render_template, redirect
from forms import RegisterForm, BookForm
from models import Book
from os import path

profiles = []


@app.route("/")
def home():
    #books = Book.query.all()
    books = Book.query.filter(Book.title == "little prince").all()
    return render_template("index.html",
                           books=books, role="admin")

@app.route("/about")
def index():
    books = Book.query.all()
    return render_template("index.html", books=books, role="admin")


@app.route("/book/<int:book_id>")
def view_book(book_id):
    book = Book.query.get(book_id)
    if book:
        return render_template("book_details.html", book=book)
    return "Book Not Found"


@app.route("/add_book", methods=["GET", "POST"])
def add_book():
    form = BookForm()
    if form.validate_on_submit():
        new_book = Book(
            title=form.title.data,
            author=form.author.data,
            rating=form.rating.data,
        )
        img = form.image.data
        new_book.image = img.filename
        if img:
            directory = path.join(app.root_path, "static", "images", img.filename)
            img.save(directory)
        db.session.add(new_book)
        db.session.commit()
        return redirect("/about")
    return render_template("add_book.html", form=form)


@app.route("/update_book/<int:book_id>", methods=["GET", "POST"])
def update_book(book_id):
    book = Book.query.get(book_id)
    form = BookForm(title=book.title, author=book.author, rating=book.rating)
    if form.validate_on_submit():
        book.title = form.title.data
        book.author = form.author.data
        book.rating = form.rating.data
        image = form.image.data
        if image:
            directory = path.join(app.root_path, "static", "images", image.filename)
            image.save(directory)
            book.image = image.filename
        db.session.commit()
        return redirect("/about")
    return render_template("add_book.html", form=form)


@app.route("/delete_book/<int:book_id>")
def delete_book(book_id):
    book = Book.query.get(book_id)
    db.session.delete(book)
    db.session.commit()
    return redirect("/about")


@app.route("/login")
def login():
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        new_user = {
            "username": form.username.data,
            "mobile": form.mobile.data,
            "date": form.birthdate.data,
        }
        img = form.image.data
        if img:
            directory = path.join(app.root_path, "static", "images", img.filename)
            new_user["img"] = img.filename
            img.save(directory)
        profiles.append(new_user)
        return redirect("/")
    return render_template("register.html", form=form)

@app.route("/profile/<int:profile_id>")
def profile(profile_id):
    p = profiles[profile_id]
    return render_template("profile.html", profile=p)


if __name__ == "__main__":
    app.run(debug=True)
