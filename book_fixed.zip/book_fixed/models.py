from sqlalchemy import ForeignKey
from ext import db

class BaseModel:
    def create(self):
        db.session.add(self)
        db.session.commit()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    @staticmethod
    def save():
        db.session.commit()


class Book(db.Model, BaseModel):
    __tablename__ = "books"

    id = db.Column(db.Integer(), primary_key=True)
    title = db.Column(db.String(), nullable=False)
    author = db.Column(db.String(), nullable=False)
    description = db.Column(db.String(), default="")
    rating = db.Column(db.Float(), default=0.0)
    image = db.Column(db.String(), default="book1.jpg")


class Review(db.Model, BaseModel):
    __tablename__ = "reviews"

    id = db.Column(db.Integer(), primary_key=True)
    text = db.Column(db.String(), nullable=False)
    book_id = db.Column(ForeignKey("books.id"))
