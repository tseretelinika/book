from ext import app, db
from models import Book, Review

with app.app_context():
    # db.drop_all()  # uncomment to reset the database
    db.create_all()  # create all tables that are imported
